// Write a javascript program that generates an alert "Not legal age to drive" if the driver age is
// below 18 years old, if driver age is greater than or equal to 18, it generates an alert "Drive safe".

//Run on browser console 
var age = 17;
if(age < 18)
{
    alert("Not legal age to drive")
}
else
{
    alert("Eligible to drive");
}