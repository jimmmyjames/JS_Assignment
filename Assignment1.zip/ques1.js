console.log(1 + "2" + "2");//String and number when concatenate it results in string
console.log(1 + +"2" + "2");// which we use + + double with string then it converts string to the number.
console.log(1 + -"1" + "2");//1 is converted to number from string.
console.log(+"1" + "1" + "2");//String is concatenated
console.log( "A" - "B" + "2");//bug + string
console.log( "A" - "B" + 2);//Bug
console.log(1 + +"2");//String is converted to number


// output :
 
// 32
// 02
// 112
// NaN2
// NaN
// 3