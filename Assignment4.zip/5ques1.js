// By how many ways we can access elements in the DOM and write about them in brief?

// We can acces dom in the following ways :

// 1) document.getElementById - we can acces with the help of id in the dom.
// 2)document.getElementsByClassName - We can access with the help of class in the dom.
// 3)document.getElementsByName() - Gets a collection of objects based on the value of the NAME or ID attribute.
// 4)document.getElementsByTagName() --- Retrieves a collection of objects based on the specified element name.

