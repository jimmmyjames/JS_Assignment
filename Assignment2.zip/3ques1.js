const clothes = ['jacket', 't-shirt'];
clothes.length = 0;
console.log(clothes[0]);

//Output : undefined since we have assigned 0 to clothes length and trying to access the index[0] which doesn't contain any value