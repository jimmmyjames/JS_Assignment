// Write a Javascript program to find the sum of all elements of a given array?

const arr = [5,4,6,7,8,9];

var sum = 0;
for(var i = 0;i<arr.length;i++)
{
  var sum = sum + arr[i];
}
console.log(sum);

//Output : 39